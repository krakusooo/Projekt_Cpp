/***************************************************************
 * Name:      logowanie_i_zak__adanie_kontApp.cpp
 * Purpose:   Code for Application Class
 * Author:    cezary_kretkowski ()
 * Created:   2020-10-26
 * Copyright: cezary_kretkowski ()
 * License:
 **************************************************************/

#include "logowanie_i_zak__adanie_kontApp.h"

//(*AppHeaders
#include "logowanie_i_zak__adanie_kontMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(logowanie_i_zak__adanie_kontApp);

bool logowanie_i_zak__adanie_kontApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	Frame = new logowanie_i_zak__adanie_kontFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);

    }
    //*)
    return wxsOK;

}


