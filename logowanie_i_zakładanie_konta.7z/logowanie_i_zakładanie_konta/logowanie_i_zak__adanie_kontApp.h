/***************************************************************
 * Name:      logowanie_i_zak__adanie_kontApp.h
 * Purpose:   Defines Application Class
 * Author:    cezary_kretkowski ()
 * Created:   2020-10-26
 * Copyright: cezary_kretkowski ()
 * License:
 **************************************************************/

#ifndef LOGOWANIE_I_ZAK__ADANIE_KONTAPP_H
#define LOGOWANIE_I_ZAK__ADANIE_KONTAPP_H

#include <wx/app.h>
#include "logowanie_i_zak__adanie_kontMain.h"
#include "NewFrame.h"

class logowanie_i_zak__adanie_kontApp : public wxApp
{
    public:

        logowanie_i_zak__adanie_kontFrame*Frame;
        virtual bool OnInit();

};

#endif // LOGOWANIE_I_ZAK__ADANIE_KONTAPP_H
