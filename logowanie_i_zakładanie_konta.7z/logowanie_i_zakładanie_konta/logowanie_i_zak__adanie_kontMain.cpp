/***************************************************************
 * Name:      logowanie_i_zak__adanie_kontMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    cezary_kretkowski ()
 * Created:   2020-10-26
 * Copyright: cezary_kretkowski ()
 * License:
 **************************************************************/

#include "logowanie_i_zak__adanie_kontMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(logowanie_i_zak__adanie_kontFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(logowanie_i_zak__adanie_kontFrame)
const long logowanie_i_zak__adanie_kontFrame::ID_BUTTON2 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::ID_TEXTCTRL1 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::ID_TEXTCTRL2 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::ID_STATICTEXT1 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::ID_STATICTEXT2 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::ID_BUTTON1 = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::idMenuQuit = wxNewId();
const long logowanie_i_zak__adanie_kontFrame::idMenuAbout = wxNewId();
//*)

BEGIN_EVENT_TABLE(logowanie_i_zak__adanie_kontFrame,wxFrame)
    //(*EventTable(logowanie_i_zak__adanie_kontFrame)
    //*)
END_EVENT_TABLE()

logowanie_i_zak__adanie_kontFrame::logowanie_i_zak__adanie_kontFrame(wxWindow* parent,wxWindowID id)
{
    new_database=new Database_Klient();
    new_database->load_from_file();
    //(*Initialize(logowanie_i_zak__adanie_kontFrame)
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(505,535));
    Button2 = new wxButton(this, ID_BUTTON2, _("Log in\n"), wxPoint(272,256), wxSize(130,30), 0, wxDefaultValidator, _T("ID_BUTTON2"));
    TextCtrl1 = new wxTextCtrl(this, ID_TEXTCTRL1, _("Text"), wxPoint(100,144), wxSize(305,24), 0, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    TextCtrl2 = new wxTextCtrl(this, ID_TEXTCTRL2, _("Text"), wxPoint(100,208), wxSize(305,24), 0, wxDefaultValidator, _T("ID_TEXTCTRL2"));
    StaticText1 = new wxStaticText(this, ID_STATICTEXT1, _("Login"), wxPoint(104,120), wxSize(64,16), 0, _T("ID_STATICTEXT1"));
    StaticText2 = new wxStaticText(this, ID_STATICTEXT2, _("Password"), wxPoint(104,184), wxSize(56,16), 0, _T("ID_STATICTEXT2"));
    Button1 = new wxButton(this, ID_BUTTON1, _("Create account"), wxPoint(104,256), wxSize(130,30), 0, wxDefaultValidator, _T("ID_BUTTON1"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    Center();

    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnButton2Click);
    Connect(ID_TEXTCTRL1,wxEVT_COMMAND_TEXT_UPDATED,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnTextCtrl1Text);
    Connect(ID_TEXTCTRL1,wxEVT_COMMAND_TEXT_ENTER,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnButton2Click);
    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnButton1Click);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&logowanie_i_zak__adanie_kontFrame::OnAbout);
    //*)
}

logowanie_i_zak__adanie_kontFrame::~logowanie_i_zak__adanie_kontFrame()
{
    //(*Destroy(logowanie_i_zak__adanie_kontFrame)
    //*)
}

void logowanie_i_zak__adanie_kontFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void logowanie_i_zak__adanie_kontFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void logowanie_i_zak__adanie_kontFrame::OnButton2Click(wxCommandEvent& event)
{
     std::string login = TextCtrl1->GetValue().ToStdString();
     std::string password = TextCtrl2->GetValue().ToStdString();
     new_database->find_login(login);
     std::string spr=new_database->node->get_password();
     if(password==spr)
     wxMessageBox("Poprawne logowanie", _("login"));
     else
     wxMessageBox("Nie poprawne logowanie", _("login"));
}

void logowanie_i_zak__adanie_kontFrame::OnTextCtrl1Text(wxCommandEvent& event)
{
}

void logowanie_i_zak__adanie_kontFrame::OnButton1Click(wxCommandEvent& event)
{
      new_frame=new NewFrame(0);
      new_frame->SetParent(this);
      new_frame->new_database_log=new_database;
      Hide();
      new_frame->Show();
}

