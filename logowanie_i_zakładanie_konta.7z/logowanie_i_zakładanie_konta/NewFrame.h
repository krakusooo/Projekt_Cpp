#ifndef NEWFRAME_H
#define NEWFRAME_H

//(*Headers(NewFrame)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/textctrl.h>
//*)
#include "Baza_danych_klienci.h"
class NewFrame: public wxFrame
{
	public:
        wxWindow *parent;
        Database_Klient *new_database_log;
		NewFrame(wxWindow* parent,wxWindowID id=wxID_ANY,const wxPoint& pos=wxDefaultPosition,const wxSize& size=wxDefaultSize);
		virtual ~NewFrame();

		//(*Declarations(NewFrame)
		wxButton* Button1;
		wxTextCtrl* TextCtrl1;
		wxTextCtrl* TextCtrl2;
		wxTextCtrl* TextCtrl3;
		//*)

	protected:

		//(*Identifiers(NewFrame)
		static const long ID_TEXTCTRL1;
		static const long ID_TEXTCTRL2;
		static const long ID_TEXTCTRL3;
		static const long ID_BUTTON1;
		//*)

	private:

		//(*Handlers(NewFrame)
		void OnClose(wxCloseEvent& event);
		void OnTextCtrl3Text(wxCommandEvent& event);
		void OnButton1Click(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
