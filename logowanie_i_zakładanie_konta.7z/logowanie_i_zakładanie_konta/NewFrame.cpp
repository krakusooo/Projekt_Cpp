#include "NewFrame.h"
#include "logowanie_i_zak__adanie_kontMain.h"
//(*InternalHeaders(NewFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(NewFrame)
const long NewFrame::ID_TEXTCTRL1 = wxNewId();
const long NewFrame::ID_TEXTCTRL2 = wxNewId();
const long NewFrame::ID_TEXTCTRL3 = wxNewId();
const long NewFrame::ID_BUTTON1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(NewFrame,wxFrame)
	//(*EventTable(NewFrame)
	//*)
END_EVENT_TABLE()

NewFrame::NewFrame(wxWindow* parent,wxWindowID id,const wxPoint& pos,const wxSize& size)
{

	//(*Initialize(NewFrame)
	Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
	SetClientSize(wxSize(505,535));
	SetFocus();
	TextCtrl1 = new wxTextCtrl(this, ID_TEXTCTRL1, _("Text"), wxPoint(100,90), wxSize(305,30), 0, wxDefaultValidator, _T("ID_TEXTCTRL1"));
	TextCtrl2 = new wxTextCtrl(this, ID_TEXTCTRL2, _("Text"), wxPoint(100,30), wxSize(305,30), 0, wxDefaultValidator, _T("ID_TEXTCTRL2"));
	TextCtrl3 = new wxTextCtrl(this, ID_TEXTCTRL3, _("Text"), wxPoint(100,150), wxSize(305,30), 0, wxDefaultValidator, _T("ID_TEXTCTRL3"));
	Button1 = new wxButton(this, ID_BUTTON1, _("Label"), wxPoint(296,264), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
	Center();

	Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&NewFrame::OnButton1Click);
	//*)
}

NewFrame::~NewFrame()
{
	//(*Destroy(NewFrame)
	//*)
    parent=this->GetParent();
    //this->Close();
    parent->Show();
}


void NewFrame::OnClose(wxCloseEvent& event)
{


}

void NewFrame::OnTextCtrl3Text(wxCommandEvent& event)
{
}

void NewFrame::OnButton1Click(wxCommandEvent& event)
{
     parent=this->GetParent();

}
