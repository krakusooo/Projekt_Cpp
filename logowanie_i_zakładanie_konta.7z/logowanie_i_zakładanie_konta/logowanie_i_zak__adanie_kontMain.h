/***************************************************************
 * Name:      logowanie_i_zak__adanie_kontMain.h
 * Purpose:   Defines Application Frame
 * Author:    cezary_kretkowski ()
 * Created:   2020-10-26
 * Copyright: cezary_kretkowski ()
 * License:
 **************************************************************/

#ifndef LOGOWANIE_I_ZAK__ADANIE_KONTMAIN_H
#define LOGOWANIE_I_ZAK__ADANIE_KONTMAIN_H

//(*Headers(logowanie_i_zak__adanie_kontFrame)
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/menu.h>
#include <wx/stattext.h>
#include <wx/textctrl.h>
//*)
#include "Baza_danych_klienci.h"

#include "NewFrame.h"

class logowanie_i_zak__adanie_kontFrame: public wxFrame
{
    public:
Database_Klient *new_database;
        logowanie_i_zak__adanie_kontFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~logowanie_i_zak__adanie_kontFrame();

    private:
        NewFrame * new_frame;

        //(*Handlers(logowanie_i_zak__adanie_kontFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnButton2Click(wxCommandEvent& event);
        void OnTextCtrl1Text(wxCommandEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        //*)

        //(*Identifiers(logowanie_i_zak__adanie_kontFrame)
        static const long ID_BUTTON2;
        static const long ID_TEXTCTRL1;
        static const long ID_TEXTCTRL2;
        static const long ID_STATICTEXT1;
        static const long ID_STATICTEXT2;
        static const long ID_BUTTON1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        //*)

        //(*Declarations(logowanie_i_zak__adanie_kontFrame)
        wxButton* Button1;
        wxButton* Button2;
        wxStaticText* StaticText1;
        wxStaticText* StaticText2;
        wxTextCtrl* TextCtrl1;
        wxTextCtrl* TextCtrl2;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // LOGOWANIE_I_ZAK__ADANIE_KONTMAIN_H
